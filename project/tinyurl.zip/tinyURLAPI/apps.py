from django.apps import AppConfig


class TinyurlapiConfig(AppConfig):
    name = 'tinyURLAPI'
